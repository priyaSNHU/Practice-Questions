from setuptools import setup

setup(
	name = 'searchvowelfun',
	version = '1.0',
	description = 'The head first python search tools',
	author = 'priyanka',
	author_email = 'bpr39912062@gmail.com',
	url = 'headfirstlabs.com',
	py_modules = ['vsearch'],
	
	)
